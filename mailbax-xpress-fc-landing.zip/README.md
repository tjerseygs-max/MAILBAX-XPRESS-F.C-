# MAILBAX XPRESS F.C. – Landing Page (Fictitious Demo)

A clean, mobile-first landing page designed for the **MAILBAX hinged QR bracelet** prototype.

When a visitor scans the unique campaign QR code on the bracelet, they land here and can choose their purpose:

- **MAILBAX** – Business inquiry  
- **Support** – Donation or purchase  
- **Sponsor** – Business partnership  

## Live Demo

This is a static single-page site ready for **GitHub Pages**.

### How to use on GitHub

1. Create a new repository (e.g. `mailbax-xpress-fc`)
2. Upload `index.html` (and optionally this `README.md`)
3. Go to **Settings → Pages**
4. Set source to the `main` branch / root
5. Your site will be live at `https://<username>.github.io/mailbax-xpress-fc/`

Or simply open `index.html` locally in any browser.

## Features

- Dark theme matching the original concept screenshots
- Fully responsive (mobile-first)
- Three interactive paths with simple forms (demo only – no backend)
- Pure HTML / CSS / vanilla JS – zero dependencies
- Ready for real form endpoints (just replace the `submitForm` function)

## Project Context

This page is part of the **MAILBAX adjustable hinged QR bracelet** OpenSCAD prototype.  
The physical bracelet carries a QR code that points to this (or a similar) campaign landing experience.

Fictitious football club branding for demonstration purposes only.

---

Made for the MAILBAX prototype · Open source demo
