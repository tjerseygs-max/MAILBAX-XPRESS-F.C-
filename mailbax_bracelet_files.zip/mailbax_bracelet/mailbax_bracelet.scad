// MAILBAX adjustable hinged QR bracelet prototype
// Units: mm. Open in OpenSCAD. Set part to "plate", "qr", "strap_a", "strap_b", or "pin".
// QR payload: mailto:george@mailbax.contact
part = "plate";
$fn=48;
qr = [[1,1,1,1,1,1,1,0,0,1,0,0,0,0,0,1,1,0,1,1,1,0,1,1,1,1,1,1,1],[1,0,0,0,0,0,1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,1,0,0,0,0,0,1],[1,0,1,1,1,0,1,0,0,1,1,1,0,0,1,0,1,0,0,1,1,0,1,0,1,1,1,0,1],[1,0,1,1,1,0,1,0,1,1,0,1,0,0,0,0,1,1,0,1,0,0,1,0,1,1,1,0,1],[1,0,1,1,1,0,1,0,0,0,1,0,1,1,1,1,0,1,1,1,0,0,1,0,1,1,1,0,1],[1,0,0,0,0,0,1,0,1,0,1,0,0,1,1,1,1,1,0,0,0,0,1,0,0,0,0,0,1],[1,1,1,1,1,1,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1],[0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0],[1,1,1,1,1,0,1,1,1,1,1,0,1,0,1,1,0,1,0,1,1,1,0,1,0,1,0,1,0],[0,1,1,1,0,1,0,0,1,1,0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1],[0,1,1,0,1,1,1,0,1,1,0,1,1,0,0,0,0,1,0,0,1,0,0,1,0,0,0,0,0],[1,0,0,1,0,0,0,1,0,1,1,1,0,0,1,0,1,0,1,0,0,0,0,1,1,1,0,0,0],[0,0,0,0,1,1,1,0,1,1,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,1,1],[0,1,1,1,1,1,0,0,0,0,1,0,1,1,1,1,0,0,0,1,1,1,0,1,1,1,0,1,1],[1,1,1,0,0,0,1,0,1,1,1,0,0,1,1,1,1,0,0,0,0,1,0,0,0,0,0,0,0],[0,0,0,0,1,0,0,0,1,0,1,0,1,1,0,1,0,0,1,1,0,1,0,0,1,1,0,0,0],[0,1,1,1,0,0,1,0,0,1,1,0,1,0,1,1,0,1,0,0,0,0,0,1,0,0,1,1,0],[1,1,1,1,1,0,0,1,0,0,0,0,0,0,0,1,1,0,1,1,1,1,1,1,1,1,1,1,1],[1,0,1,1,0,1,1,0,0,0,0,1,1,0,0,0,0,0,1,0,0,0,1,1,0,1,1,0,0],[1,0,0,1,1,1,0,1,0,0,1,1,0,0,1,0,1,0,0,0,1,0,0,1,0,0,0,0,0],[1,0,0,1,0,1,1,1,1,0,0,1,0,0,0,0,1,1,0,1,1,1,1,1,1,1,1,0,1],[0,0,0,0,0,0,0,0,1,0,1,0,1,1,1,1,0,0,1,0,1,0,0,0,1,0,1,1,1],[1,1,1,1,1,1,1,0,1,0,1,0,0,1,1,1,1,1,1,1,1,0,1,0,1,0,1,0,0],[1,0,0,0,0,0,1,0,0,1,0,0,1,1,0,1,0,0,0,1,1,0,0,0,1,1,0,0,0],[1,0,1,1,1,0,1,0,1,1,0,0,1,0,1,1,0,1,0,0,1,1,1,1,1,0,1,0,1],[1,0,1,1,1,0,1,0,1,0,0,0,0,0,0,1,1,0,0,1,0,0,0,0,0,1,0,0,0],[1,0,1,1,1,0,1,0,1,1,0,1,1,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,0],[1,0,0,0,0,0,1,0,1,1,1,1,0,0,1,0,1,0,1,0,1,1,0,1,1,1,0,1,0],[1,1,1,1,1,1,1,0,1,1,0,1,0,0,0,0,0,0,1,1,0,0,0,1,1,0,1,0,0]];
N = len(qr);
module hinge_barrel(yc) {
  // PLA knuckle, barrel axis across plate width (X)
  translate([0,yc,3.0]) difference() {
    rotate([0,90,0]) cylinder(h=24, r=3.0, center=true);
    rotate([0,90,0]) cylinder(h=25, r=1.65, center=true);
  }
}
module plate() {
  difference() {
    union() {
      // Rounded rectangle base
      hull() for (x=[-21,21], y=[-25,25]) translate([x,y,0]) cylinder(h=3,r=2);
      hinge_barrel(29);
      hinge_barrel(-29);
      // raised perimeter lip
      translate([0,0,2.9]) difference() {
        linear_extrude(height=0.5) offset(r=1.5) square([43,49],center=true);
        translate([0,0,-0.1]) linear_extrude(height=0.8) offset(r=1.0) square([41,47],center=true);
      }
    }
    // recess zone for QR tiles, centered in top half
    translate([0,5,2.65]) cube([36.5,36.5,1],center=true);
  }
}
module qr_tiles() {
  // Individual black PLA modules. Print separately; place into shallow QR field or print as a second color.
  cell=36/(N+8); // includes four-module quiet zone on every side
  for (r=[0:N-1], c=[0:N-1]) if (qr[r][c]==1)
    translate([-18+4*cell+(c+0.5)*cell, 5+18-4*cell-(r+0.5)*cell, 2.7]) cube([cell*0.96,cell*0.96,0.8],center=true);
}
module strap_base(len=100) {
  // 25.4 mm wide x 2.6 mm TPU strap, main body extends down from hinge eyelet
  union() {
    // strap web, starts just after hinge eyelet
    translate([0,-len/2-3,0]) cube([25.4,len,2.6],center=true);
    // eyelet at plate end, axis X; outer diameter 7mm
    difference() {
      translate([0,-3,3.5]) rotate([0,90,0]) cylinder(h=25.4,r=3.5,center=true);
      translate([0,-3,3.5]) rotate([0,90,0]) cylinder(h=26,r=1.7,center=true);
    }
    // reinforce the web-to-eyelet transition
    hull() {
      translate([0,-6,1.3]) cube([25.4,10,2.6],center=true);
      translate([0,-3,3.2]) rotate([0,90,0]) cylinder(h=25.4,r=3.0,center=true);
    }
  }
}
module strap_a() {
  difference() {
    union() {
      strap_base(100);
      // rounded mushroom studs for adjustable overlap, along strap centerline
      for (p=[-82,-70,-58,-46,-34]) translate([0,p,2.6]) cylinder(h=2.0,r=2.4);
    }
  }
}
module strap_b() {
  difference() {
    strap_base(100);
    // receiving holes in far half of strap; 8mm pitch, sized for stretch fit over studs
    for (p=[-82,-70,-58,-46,-34]) translate([0,p,-0.2]) cylinder(h=3.2,r=2.0);
  }
}
module pin() {
  // Two hinge pins, print vertically; one spare-length pin for trimming to 25mm.
  translate([0,0,0]) cylinder(h=25.2,r=1.45);
  translate([0,0,25.2]) cylinder(h=1.2,r=2.0);
}
if (part=="plate") plate();
else if (part=="qr") qr_tiles();
else if (part=="strap_a") strap_a();
else if (part=="strap_b") strap_b();
else if (part=="pin") pin();
