MAILBAX hinged adjustable QR bracelet — prototype files

FILES
- plate.stl: rigid PLA plaque with hinge barrels and QR field
- qr.stl: separate raised black QR modules; encoded payload is mailto:george@mailbax.contact
- strap_a.stl: TPU strap with adjustable studs
- strap_b.stl: TPU strap with matching adjustment holes
- pin.stl: hinge pin (print two; trim/fit as needed)
- mailbax_bracelet.scad: editable OpenSCAD source; select part via the `part` variable

DESIGN TARGETS
- Strap width: 25.4 mm (1 inch)
- Strap body length: 100 mm each half
- Plate body: approximately 44 x 52 mm; hinge barrels extend the length
- QR payload: mailto:george@mailbax.contact
- Adjustable closure uses a row of TPU studs and holes; hinge pins connect the strap eyelets to the PLA plate.

PRINTING NOTES
- Prototype only; dimensions may need tuning for your printer, wrist size, and filament.
- PLA: plate, QR modules, and hinge pins. TPU: both straps.
- Suggested starting settings: 0.2 mm layers; 3-4 walls; 20-40% infill for plate; 100% infill for small pins; TPU slow speed.
- Print QR modules in black and the plate in white for scan contrast. Keep the QR quiet zone clear; do not paint or cover it.
- QR is encoded as a mailto: URI, which should open an email composer on compatible phones. It does not represent a web page.
- Test QR scanning from a printed sample before producing a batch. If your slicer changes module spacing or the print has poor contrast, adjust before use.
- The pin and hinge geometry are prototype dimensions. Check free pivot movement and retention before wearing. Do not use as a safety-critical clasp or for children without supervision.
